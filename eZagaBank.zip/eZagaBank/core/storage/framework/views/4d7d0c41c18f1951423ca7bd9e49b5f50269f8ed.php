<?php $__env->startSection('title', 'DEPOSITS'); ?>
<?php $__env->startSection('DEPOSITS', 'active'); ?>
<?php $__env->startSection('content'); ?>
    <main class="app-content">
        <div class="app-title">
            <div>
                <h1><i class="icon fa fa-desktop"></i> <?php echo app('translator')->getFromJson('DEPOSITS'); ?></h1>
            </div>
        </div>
        <div class="tile">
            <table class="table table-hover">
                <thead>
                <tr>
                    <th>
                        <?php echo app('translator')->getFromJson('Username'); ?>
                    </th>
                    <th>
                       <?php echo app('translator')->getFromJson('Amount'); ?>
                    </th>
                     <th>
                       <?php echo app('translator')->getFromJson('Charge'); ?>
                    </th>
                    <th>
                        <?php echo app('translator')->getFromJson('Gateway'); ?>
                    </th>
                    <th>
                        <?php echo app('translator')->getFromJson('Status'); ?>
                    </th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $deposits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $depo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <a href="<?php echo e(route('admin.userDetails',$depo->user_id)); ?>"><?php echo e($depo->userName->username); ?></a>
                        </td>
                        <td>
                            <?php echo e($depo->amount); ?> <?php echo e($gnl->cur); ?>

                        </td>
                        <td>
                            <?php echo e($depo->charge); ?> <?php echo e($gnl->cur); ?>

                        </td>
                        <td>
                        <?php echo e($depo->gateway->name); ?>


                        <td>
                            <span class="badge <?php echo e($depo->status==1?'badge-success':'badge-warning'); ?>"><?php echo e($depo->status==1?'Complete':'Pending'); ?></span>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tbody>
            </table>
            <?php echo e($deposits->links()); ?>

        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>