<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->getFromJson('Contact'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('frontend.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <section class="contact-area section-padding">
        <div class="container">
            <div class="row mb-60">
                <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 col-md-6 col-sm-12 col-xs-12">
                    <div class="single-contact-block">
                        <span><i class="<?php echo e($contact->icon); ?>"></i></span>
                        <h4 class="margin-bottom-10"><?php echo e(__($contact->title)); ?></h4>
                        <p><?php echo e(__($contact->name)); ?></p>
                    </div>
                </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>

            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="contact-form">
                        <form action="<?php echo e(route('ContactSubmit')); ?>" method="post" id="contact_form_submit">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
                                    <input type="text" name="name" placeholder="<?php echo app('translator')->getFromJson('Name'); ?>">
                                </div>
                                <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
                                    <input type="text" name="subject" placeholder="<?php echo app('translator')->getFromJson('Subject'); ?>">
                                </div>
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <input type="email" name="email" placeholder="<?php echo app('translator')->getFromJson('Email'); ?>">
                                </div>
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <textarea name="message" rows="4" placeholder="<?php echo app('translator')->getFromJson('Write Messages'); ?>"></textarea>
                                </div>
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <button type="submit" class="bttn btn-fill"><?php echo app('translator')->getFromJson('Submit Message'); ?></button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>