<?php $__env->startSection('title', 'Other Banks'); ?>
<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <main class="app-content">
        <div class="app-title">
            <div>
                <h1> Other Banks</h1>
            </div>
            <div class="app-search">
                <button class="btn btn-circle  btn-primary" data-toggle="modal" data-target="#newMethod">
                    <i class="fa fa-plus"></i> Add New Bank
                </button>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="tile">
                    <div class="row">
                        <?php $__currentLoopData = $banks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-4" style="margin-top:10px;">
                                <div class="card text-white <?php echo e($data->status==1?'bg-dark':'bg-secondary'); ?>">
                                    <div class="card-header text-center">
                                        <?php echo e($data->name); ?>

                                    </div>
                                    <div class="card-body">
                                        <form method="post" action="<?php echo e(route('admin.other.banks.update', $data->id)); ?>" enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>
                                            <div class="form-group">
                                                <label for="status">Status</label>
                                                <select class="form-control" name="status">
                                                    <option value="1" <?php echo e($data->status == "1" ? 'selected' : ''); ?>>Active</option>
                                                    <option value="0" <?php echo e($data->status == "0" ? 'selected' : ''); ?>>Deactive</option>
                                                </select>
                                            </div>
                                            <button class="btn btn-info btn-block btn-sm" type="button" data-toggle="collapse" data-target="#collapseExample<?php echo e($data->id); ?>" aria-expanded="false" aria-controls="collapseExample">
                                                <i class="fa fa-eye"></i> DETAILS
                                            </button>
                                            <div class="collapse" id="collapseExample<?php echo e($data->id); ?>">
                                                <hr/>
                                                <div class="form-group">
                                                    <label>Bank name</label>
                                                    <input type="text" value="<?php echo e($data->name); ?>" class="form-control" id="name" name="name" >
                                                </div>

                                                <hr/>
                                                <div class="card text-center text-dark">
                                                    <div class="card-header">
                                                        Transaction Limit
                                                    </div>
                                                    <div class="card-body">
                                                        <div class="row">
                                                            <div class="col-md-6">
                                                                <div class="form-group">
                                                                    <label for="minamo">Minimum Amount</label>
                                                                    <div class="input-group">
                                                                        <input type="text" value="<?php echo e($data->min_amount); ?>" class="form-control" id="minamo" name="min_amount" >
                                                                        <div class="input-group-append">
                                                        <span class="input-group-text">
                                                            <?php echo e($gnl->cur); ?>

                                                        </span>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="form-group">
                                                                    <label for="maxamo">Maximum Amount</label>
                                                                    <div class="input-group">
                                                                        <input type="text" value="<?php echo e($data->max_amount); ?>" class="form-control" id="maxamo" name="max_amount" >
                                                                        <div class="input-group-append">
                                                        <span class="input-group-text">
                                                            <?php echo e($gnl->cur); ?>

                                                        </span>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <hr/>
                                                <div class="card text-center text-dark">
                                                    <div class="card-header">
                                                        Transaction Charge
                                                    </div>
                                                    <div class="card-body">
                                                        <div class="row">
                                                            <div class="col-md-6">
                                                                <div class="form-group">
                                                                    <label for="chargefx">Fixed Charge</label>
                                                                    <div class="input-group">
                                                                        <input type="text" value="<?php echo e($data->fixed_charge); ?>" class="form-control" id="chargefx" name="fixed_charge" >
                                                                        <div class="input-group-append">
                                                        <span class="input-group-text">
                                                            <?php echo e($gnl->cur); ?>

                                                        </span>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="form-group">
                                                                    <label for="chargepc">Charge in Percentage</label>
                                                                    <div class="input-group">
                                                                        <input type="text" value="<?php echo e($data->percent_charge); ?>" class="form-control" id="chargepc" name="percent_charge" >
                                                                        <div class="input-group-append">
                                                        <span class="input-group-text">
                                                            %
                                                        </span>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <hr/>
                                        <div class="card text-center text-dark">
                                                    <div class="card-header">
                                                        Processing time
                                                    </div>
                                                    <div class="card-body">
                                                        <div class="row">
                                                            <div class="col-md-12">
                                                                <div class="form-group">

                                                                    <div class="input-group">
                                                                        <input type="text" value="<?php echo e($data->p_time); ?>" class="form-control" id="chargefx" name="processing_time" >
                                                                        <div class="input-group-append">

                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>

                                                        </div>
                                                    </div>
                                                </div>
                                                <hr/>

                                            </div>

                                            <hr/>
                                            <div class="form-group">
                                                <button type="submit" class="btn btn-success btn-block">Update</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>


            </div>
        </div>
    </main>


    <div id="newMethod" class="modal fade" role="dialog">
        <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">New Bank</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>

                </div>
                <div class="modal-body">
                    <form method="post" action="<?php echo e(route('admin.other.banks.create')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <div class="form-group">
                            <label>Bank name</label>
                            <input type="text" class="form-control" id="name" name="name" >
                        </div>

                        <hr/>
                        <div class="card text-center text-dark">
                            <div class="card-header">
                                Transaction  Limit
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="minamo">Minimum Amount</label>
                                            <div class="input-group">
                                                <input type="text"  class="form-control" id="minamo" name="min_amount" >
                                                <div class="input-group-append">
                                                            <span class="input-group-text">
                                                                <?php echo e($gnl->cur); ?>

                                                            </span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="maxamo">Maximum Amount</label>
                                            <div class="input-group">
                                                <input type="text"  class="form-control" id="maxamo" name="max_amount" >
                                                <div class="input-group-append">
                                                            <span class="input-group-text">
                                                                <?php echo e($gnl->cur); ?>

                                                            </span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <hr/>
                        <div class="card text-center text-dark">
                            <div class="card-header">
                                Transaction  Charge
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="chargefx">Fixed Charge</label>
                                            <div class="input-group">
                                                <input type="text" class="form-control" id="chargefx" name="fixed_charge" >
                                                <div class="input-group-append">
                                                            <span class="input-group-text">
                                                                <?php echo e($gnl->cur); ?>

                                                            </span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="chargepc">Charge in Percentage</label>
                                            <div class="input-group">
                                                <input type="text"  class="form-control" id="chargepc" name="percent_charge" >
                                                <div class="input-group-append">
                                                            <span class="input-group-text">
                                                                %
                                                            </span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <hr/>
                        <div class="card text-center text-dark">
                            <div class="card-header">
                                Processing time
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">

                                            <div class="input-group">
                                                <input type="text"  class="form-control" name="processing_time" >
                                                <div class="input-group-append">

                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>

                        <hr/>
                        <div class="form-group">
                            <label for="status">Status</label>
                            <select class="form-control" name="status">
                                <option value="1">Active</option>
                                <option value="0">Deactive</option>
                            </select>
                        </div>


                        <hr/>
                        <div class="form-group">
                            <button type="submit" class="btn btn-success btn-block">Create</button>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_scripts'); ?>
    <script src="<?php echo e(asset('assets/admin/js/bootstrap-fileinput.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>