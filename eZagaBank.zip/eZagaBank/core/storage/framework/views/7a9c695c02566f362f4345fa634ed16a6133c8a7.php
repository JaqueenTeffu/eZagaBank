<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->getFromJson('Latest news'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('frontend.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <section id="wcu">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-10 col-lg-8 text-center">
                    <div class="heading-title">
                        <h2>
                            <?php echo app('translator')->getFromJson('Latest news'); ?>
                        </h2>
                        <div class="sectionSeparator"></div>

                    </div>
                </div>
            </div>
            <div class="row">
                <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4">
                        <div class="box">
                            <div class="img">
                                <a href="<?php echo e(route('single.blog',[$blog->id, strtolower(urlencode($blog->title))])); ?>">  <img class="img-fluid" src="<?php echo e(asset('assets/image/blog/'.$blog->image)); ?>" alt=""> </a>
                            </div>
                            <div class="content">
                                <a href="<?php echo e(route('single.blog',[$blog->id, strtolower(urlencode($blog->title))])); ?>"> <h3>
                                        <?php echo e(__($blog->title)); ?>

                                    </h3> </a>
                                <p>
                                    <?php echo e(__(str_limit( $blog->description, $limit = 250, $end = '....'))); ?>

                                </p>

                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>