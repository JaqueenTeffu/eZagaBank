<?php $__env->startSection('profile', 'active'); ?>
<?php $__env->startSection('title'); ?>
    <?php echo e(Auth::user()->name); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/user/fileInput/bootstrap-fileinput.css')); ?>">
    <?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('user.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>




    <section id="paymentMethod">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-10 col-lg-10 text-center">
                    <div class="heading-title padding-bottom-70">
                        <h2>
                            <?php echo app('translator')->getFromJson('Account Settings'); ?>
                        </h2>
                        <div class="sectionSeparator"></div>

                    </div>
                </div>
            </div>

            <div class="row calculate justify-content-center">

                <div class="col-md-6 col-lg-3">
                    <div class="sbox">
                        <div class="image">
                            <form method="post" action="<?php echo e(route('user.profile.image.upload')); ?>" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>

                                <div class="form-group col-md-12">
                                    <div class="fileinput fileinput-new" data-provides="fileinput" >
                                        <div class="fileinput-new thumbnail" style="max-width: 252px; max-height: 252px;">
                                            <?php if(Auth::user()->avatar != NULL): ?>
                                                <img   src="<?php echo e(asset('assets/image/avatar/'.Auth::user()->avatar)); ?>" alt="">

                                            <?php else: ?>
                                                <img class="img-fluid" src="<?php echo e(asset('assets/image/user.png')); ?>" alt="">
                                            <?php endif; ?>
                                        </div>

                                        <div class="fileinput-preview fileinput-exists thumbnail" style="max-width: 512px; max-height: 512px;"> </div>
                                        <div>
                                                <span class="btn btn-info btn-file">
                                                     <span class="fileinput-new"> <?php echo app('translator')->getFromJson('Change'); ?> </span>
                                                    <span class="fileinput-exists"> <?php echo app('translator')->getFromJson('Change'); ?> </span>
                                                 <input type="file" name="avatar"> </span>
                                            <a href="javascript:;" class="btn btn-danger fileinput-exists" data-dismiss="fileinput"> <?php echo app('translator')->getFromJson('Remove'); ?> </a>
                                        </div>
                                        <code><?php echo app('translator')->getFromJson('Avatar will be crop width: 512px; height: 512px'); ?></code>
                                    </div>
                                </div>
                                <div class="tile-footer">
                                    <button class="btn mr_btn_solid" style="  width: 100%!important; margin-bottom: 20px;" type="submit"><?php echo app('translator')->getFromJson('Update'); ?></button>
                                </div>
                            </form>

                        </div>

                    </div>
                </div>

                <div class="col-md-12 col-lg-9">
                    <div class="box">

                        <form action="<?php echo e(route('user.profile.update')); ?>" method="post" class="form-horizontal form-bordered">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="form-group col-md-6">
                                    <label for="exampleInputEmail1"><?php echo app('translator')->getFromJson('First Name'); ?></label>
                                    <input class="form-control" type="text" name="first_name" value="<?php echo e(Auth::user()->first_name); ?>">
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="exampleInputEmail1"><?php echo app('translator')->getFromJson('Last Name'); ?></label>
                                    <input class="form-control" type="text" name="last_name" value="<?php echo e(Auth::user()->last_name); ?>">
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="exampleInputEmail1"><?php echo app('translator')->getFromJson('Phone Number'); ?></label>
                                    <input class="form-control" type="text" name="phone" value="<?php echo e(Auth::user()->phone); ?>">
                                </div>
                                <div class="form-group col-md-6">
                                    <fieldset>
                                        <label class="control-label" ><?php echo app('translator')->getFromJson('Email'); ?></label>
                                        <input class="form-control"  value="<?php echo e(Auth::user()->email); ?>" placeholder="Readonly input here…" readonly="">
                                    </fieldset>
                                </div>
                                <div class="form-group col-md-12">
                                    <fieldset>
                                        <label class="control-label" for="readOnlyInput"><?php echo app('translator')->getFromJson('Username'); ?></label>
                                        <input class="form-control"  value="<?php echo e(Auth::user()->username); ?>" placeholder="Readonly input here…" readonly="">
                                    </fieldset>
                                </div> <div class="form-group col-md-12">
                                    <fieldset>
                                        <label class="control-label" for="readOnlyInput"><?php echo app('translator')->getFromJson('Account Number'); ?></label>
                                        <input class="form-control"  value="<?php echo e(Auth::user()->account_number); ?>" placeholder="Readonly input here…" readonly="">
                                    </fieldset>
                                </div>



                            </div>
                            <div class="tile-footer">
                                <button class="btn mr_btn_solid" style="  width: 100%!important; margin-bottom: 20px;" type="submit"><?php echo app('translator')->getFromJson('Update'); ?></button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script type="text/javascript" src="<?php echo e(asset('assets/user/fileInput/bootstrap-fileinput.js')); ?>"></script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('user', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>