<?php $__env->startSection('title'); ?>
   <?php echo app('translator')->getFromJson('Withdraw Approve'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <main class="app-content">

        <div class="raw">
            <div class="col-lg-12">
                <div class="tile">
                    <div class="table-responsive">
                        <table class="table table-hover text-center">
                            <thead>
                            <tr>
                                <th> <?php echo app('translator')->getFromJson('Username'); ?></th>
                                <th> <?php echo app('translator')->getFromJson('Amount'); ?></th>
                                <th> <?php echo app('translator')->getFromJson('Charge'); ?></th>
                                <th> <?php echo app('translator')->getFromJson('Method'); ?></th>
                                <th> <?php echo app('translator')->getFromJson('Account'); ?></th>
                                <th> <?php echo app('translator')->getFromJson('Requested At'); ?></th>
                                <th> <?php echo app('translator')->getFromJson('Rejected At'); ?></th>
                                <th> <?php echo app('translator')->getFromJson('Status'); ?></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php if(count($rejects)==0): ?>
                                <tr>
                                    <td colspan="7"><h2><?php echo app('translator')->getFromJson('No Data Available'); ?></h2></td>
                                </tr>
                            <?php endif; ?>
                            <?php $__currentLoopData = $rejects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td> <a href="<?php echo e(route('admin.userDetails',$log->user->id)); ?>"> <?php echo e($log->user->username); ?> </a></td>
                                    <td><?php echo e($log->amount); ?> <?php echo e($gnl->cur); ?></td>
                                    <td><?php echo e($log->fee); ?> <?php echo e($gnl->cur); ?></td>
                                    <td><?php echo e($log->wmethod->name); ?></td>
                                    <td><?php echo e($log->account); ?></td>
                                    <td><?php echo e($log->created_at->diffForHumans()); ?></td>
                                    <td><?php echo e($log->updated_at->diffForHumans()); ?></td>
                                    <td> <span class="badge badge-danger"><?php echo app('translator')->getFromJson('rejected'); ?></span></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>

                        </table>
                        <div class="d-flex flex-row-reverse">
                            <?php echo e($rejects->links()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>