<?php $__env->startSection('user', 'active'); ?>
<?php $__env->startSection('title'); ?>
    Withdraw request
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <main class="app-content">

        <div class="raw">
            <div class="col-lg-12">
                <div class="tile">
                    <div class="table-responsive">
                        <table class="table table-hover text-center">
                            <thead>
                            <tr>
                                <th> <?php echo app('translator')->getFromJson('Username'); ?></th>
                                <th> <?php echo app('translator')->getFromJson('Amount'); ?></th>
                                <th> <?php echo app('translator')->getFromJson('Method'); ?></th>
                                <th> <?php echo app('translator')->getFromJson('Account'); ?></th>
                                <th> <?php echo app('translator')->getFromJson('TRX Time'); ?></th>
                                <th> <?php echo app('translator')->getFromJson('Status'); ?></th>
                                <th> <?php echo app('translator')->getFromJson('Action'); ?></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php if(count($reqs)==0): ?>
                                <tr>
                                    <td colspan="7"><h2><?php echo app('translator')->getFromJson('No Data Available'); ?></h2></td>
                                </tr>
                            <?php endif; ?>
                            <?php $__currentLoopData = $reqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td> <a href="<?php echo e(route('admin.userDetails',$log->user->id)); ?>"> <?php echo e($log->user->username); ?> </a></td>
                                    <td><?php echo e($log->amount); ?> <?php echo e($gnl->cur); ?></td>
                                    <td><?php echo e($log->wmethod->name); ?></td>
                                    <td><?php echo e($log->account); ?></td>
                                    <td><?php echo e($log->created_at->diffForHumans()); ?></td>
                                    <td><?php if($log->status == 0): ?> <span class="badge badge-warning"><?php echo app('translator')->getFromJson('Pending'); ?></span> <?php elseif($log->status == 1): ?> <span class="badge badge-success"><?php echo app('translator')->getFromJson('Approve'); ?></span>   <?php elseif($log->status == 2): ?> <span class="badge badge-danger"><?php echo app('translator')->getFromJson('Refund'); ?></span>   <?php endif; ?></td>

                                    <td>
                                       <button class="btn btn-success approveButton" data-toggle="modal"  data-gate="<?php echo e($log->id); ?>"  data-target="#approveModal" ><i class="fa fa-check "></i> Approve</button>
                                        <button  class="btn btn-danger rejectButton" data-toggle="modal"  data-gate="<?php echo e($log->id); ?>"  data-target="#rejectModal" ><i class="fa fa-times"></i>  Reject</button>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>

                        </table>
                        <div class="d-flex flex-row-reverse">
                            <?php echo e($reqs->links()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>


    <div class="modal fade" id="approveModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="ModalLabel"><?php echo app('translator')->getFromJson('Are you sure you wnat to approve this?'); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('admin.withdraw.approve')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="withdraw" id="withdrawApprove"/>

                        <div class="modal-footer">

                            <button type="submit" class="btn btn-success"><?php echo app('translator')->getFromJson('Approve'); ?></button>
                            <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo app('translator')->getFromJson('Close'); ?></button>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>
<div class="modal fade" id="rejectModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="ModalLabel"><?php echo app('translator')->getFromJson('Are you sure you wnat to reject this?'); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('admin.withdraw.reject')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="withdraw" id="withdrawReject"/>

                        <div class="modal-footer">

                            <button type="submit" class="btn btn-danger"><?php echo app('translator')->getFromJson('Reject'); ?></button>
                            <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo app('translator')->getFromJson('Close'); ?></button>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>

        $(document).ready(function(){
            $(document).on('click','.approveButton', function(){
                $('#withdrawApprove').val($(this).data('gate'));
            });
            $(document).on('click','.rejectButton', function(){
                $('#withdrawReject').val($(this).data('gate'));
            });
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>