<?php $__env->startSection('changePass', 'active'); ?>
<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->getFromJson('Change Password'); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('user.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>




    <section id="paymentMethod">
        <div class="container">
           
            <div class="row calculate justify-content-center">
                <div class="col-md-10 col-lg-12">
                    <div class="box">

                        <form action="<?php echo e(route('user.password.change')); ?>" method="post" class="form-horizontal form-bordered" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="form-group col-md-12">
                                    <label for="exampleInputEmail1"><?php echo app('translator')->getFromJson('Old Password'); ?></label>
                                    <input class="form-control" name="old_password" type="password"  placeholder="<?php echo app('translator')->getFromJson('Old Password'); ?>" required>
                                </div>
                                <div class="form-group col-md-12">
                                    <label for="exampleInputEmail1"><?php echo app('translator')->getFromJson('New Password'); ?></label>
                                    <input class="form-control" name="password" type="password"  placeholder="<?php echo app('translator')->getFromJson('New Password'); ?>" required>
                                </div>

                                <div class="form-group col-md-12">
                                    <label class="control-label" for="readOnlyInput"><?php echo app('translator')->getFromJson('Confirm Password'); ?></label>
                                    <input class="form-control"  name="password_confirmation"  type="password" placeholder="<?php echo app('translator')->getFromJson('Confirm Password'); ?>" required>
                                </div>

                            </div>
                            <div class="tile-footer">
                                <button class="btn mr_btn_solid" style="  width: 100%!important; margin-bottom: 20px;" type="submit"><?php echo app('translator')->getFromJson('Change'); ?></button>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('user', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>