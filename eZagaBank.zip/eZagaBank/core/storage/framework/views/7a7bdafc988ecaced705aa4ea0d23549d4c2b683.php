<?php $__env->startSection('slider', 'active'); ?>
<?php $__env->startSection('title', 'Sliders'); ?>
<?php $__env->startSection('content'); ?>
    <main class="app-content">
        <div class="app-title">
            <div>
                <h1><i class="fa fa-image"></i> Sliders</h1>

            </div>
          <a href="<?php echo e(route('admin.slider.add')); ?>">  <button class="btn btn-primary pull-right bold"><i class="fa fa-plus"></i> Add New Slider</button> </a>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="tile">

                    <div class="tile-body">
                        <div class="table-responsive">

                            <table class="table table-bordered table-hover">
                                <thead>
                                <tr>
                                    <th scope="col">ID</th>
                                    <th scope="col">Name</th>
                                    <th scope="col">Subtitle</th>
                                    <th scope="col">Actions</th>
                                </tr>
                                </thead>
                                <tbody id="products-list" name="products-list">
                                <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr id="product3">
                                        <td ><?php echo e($loop->iteration); ?></td>
                                        <td ><?php echo e($data->title); ?></td>
                                        <td > <?php echo e($data->subtitle); ?></td>

                                        <td data-label="Action">
                                          <a href="<?php echo e(route('admin.slider.edit', $data->id)); ?>" > <button type="button" class="btn btn-primary btn-detail open_modal bold uppercase"><i class="fa fa-edit"></i></button> </a>
                                            <button type="submit" class="btn btn-danger bold"data-toggle="modal" data-target="#delete-<?php echo e($data->id); ?>"> <i class="fa fa-trash"></i></button>
                                        </td>
                                    </tr>


                                    <div class="modal fade" id="delete-<?php echo e($data->id); ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h4 class="modal-title danger" id="myModalLabel2"><i class='fa fa-trash '></i> <span class="danger">Are you sure you want to delete this?</span></h4>
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <form method="post" action="<?php echo e(route('admin.slider.delete',$data->id)); ?>" class="action-route">
                                                    <?php echo csrf_field(); ?>
                                                    <div class="modal-body">
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="submit" class="btn btn-success"> Yes</button>
                                                        <button type="button" class="btn btn-danger" data-dismiss="modal"> No</button>&nbsp;
                                                    </div>
                                                </form>

                                            </div>
                                        </div>
                                    </div>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>

                            </table>
                        </div>

                    </div>
                </div>
            </div>
        </div>

    </main>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>