<?php $__env->startSection('deposit_ht', 'active'); ?>
<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->getFromJson('Account Statement'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb-title'); ?>
    <?php echo app('translator')->getFromJson('Deposit history'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('user.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>




    <!-- Modal -->
    <section id="transaction">
        <div class="container">
            
            <div class="row justify-content-center">
                <div class="col-md-12 col-lg-12">
                    <div class="tab1">
                        <ul class="nav nav-pills" id="pills-tab" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link active show" id="pills-deposit-tab" data-toggle="pill" href="#pills-deposit" role="tab" aria-controls="pills-deposit" aria-selected="true">
                                    <p>
                                       <?php echo app('translator')->getFromJson('Own bank'); ?>
                                    </p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="pills-withdraw-tab" data-toggle="pill" href="#other-bank" role="tab" aria-controls="pills-withdraw" aria-selected="false">
                                    <p>
                                      <?php echo app('translator')->getFromJson('Other bank'); ?>
                                    </p>
                                </a>
                            </li>
                        </ul>
                        <div class="tab-content" id="pills-tabContent">
                            <div class="tab-pane fade active show" id="pills-deposit" role="tabpanel" aria-labelledby="pills-deposit-tab">
                                <div class="table-responsive">
                                    <table class="table">


                                        <thead>

                                        <tr>
                                            <th class="text-center"><?php echo app('translator')->getFromJson('Date'); ?></th>
                                            <th class="text-center"><?php echo app('translator')->getFromJson('Description'); ?></th>
                                            <th class="text-center"><?php echo app('translator')->getFromJson('Amount'); ?></th>
                                            <th class="text-center"><?php echo app('translator')->getFromJson('After Balance'); ?></th>

                                        </tr>
                                        </thead>
                                        <tbody>

                                        <?php if(count($ownBankStatements) == 0): ?>
                                            <tr>
                                                <td colspan="4"><h2><?php echo app('translator')->getFromJson('No Data Available'); ?></h2></td>
                                            </tr>
                                        <?php else: ?>


                                        <?php $__currentLoopData = $ownBankStatements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $statement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <?php echo e($statement->created_at); ?>

                                            </td>
                                            <td>
                                                <?php echo e($statement->details); ?>

                                            </td>
                                            <td>
                                                <?php echo e($statement->amount); ?> <?php echo e($gnl->cur_symbol); ?>

                                            </td>
                                            <td>
                                                <?php echo e($statement->balance); ?> <?php echo e($gnl->cur_symbol); ?>

                                            </td>



                                        </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="other-bank" role="tabpanel" aria-labelledby="pills-withdraw-tab">
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>

                                            <tr>
                                                <th class="text-center"><?php echo app('translator')->getFromJson('Date'); ?></th>
                                                <th class="text-center"><?php echo app('translator')->getFromJson('Amount'); ?></th>
                                                <th class="text-center"><?php echo app('translator')->getFromJson('After balance'); ?></th>
                                                <th class="text-center"><?php echo app('translator')->getFromJson('Account info'); ?></th>
                                                <th class="text-center"><?php echo app('translator')->getFromJson('Processing time'); ?></th>
                                                <th class="text-center"><?php echo app('translator')->getFromJson('Status'); ?></th>
                                        </tr>
                                        </thead>
                                        <tbody>

                                        <?php if(count($otherBankStatements) == 0): ?>
                                            <tr>
                                                <td colspan="6"><h2><?php echo app('translator')->getFromJson('No Data Available'); ?></h2></td>
                                            </tr>
                                        <?php else: ?>

                                            <?php $__currentLoopData = $otherBankStatements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <?php echo e($data->created_at); ?>

                                            </td>

                                            <td>
                                                <?php echo e($data->amount); ?> <?php echo e($gnl->cur_symbol); ?>

                                            </td>
                                            <td>
                                                <?php echo e($data->balance); ?> <?php echo e($gnl->cur_symbol); ?>

                                            </td>
                                            <td>
                                                 <?php echo e($data->details); ?>

                                            </td>

                                            <td>
                                                <?php echo e($data->p_time); ?>

                                            </td>
                                            <td>
                                                <?php if($data->status == 0): ?> pending <?php elseif($data->status == 1): ?> Confirm <?php elseif($data->status == 3): ?> Refund <?php endif; ?>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('user', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>