<?php $__env->startSection('Language', 'active'); ?>
<?php $__env->startSection('title', 'Language Edit'); ?>


<?php $__env->startSection('content'); ?>
    <main class="app-content">
        <div  id="app">

            <div class="card">
                <div class="card-header bg-white font-weight-bold">
                    <div class="row">
                        <div class="col-md-8">
                            <h3 class="tile-title"> <?php echo e($page_title); ?> (<small>Click Add Translatable Add Put Your Key For Translate</small>)</h3>
                            <small style="color: red">"Add Translatable Key" please careful when you entering word or sentences, there shouldn't be any extra space or break. </small>
                            <small style="color: green">If your keywords are perfect but translator doesn't work, don't worry. escape all dynamic keywords and add single word, it'll work  . </small>
                        </div>
                        <div class="col-md-4">
                            <form class="form-inline" method="post" @submit.prevent="importKey">

                                <div class="form-group mb-2">
                                    <select  class="form-control" required v-model="importData.code">
                                        <option value="">Import Keywords (Select Language)</option>
                                        <?php $__currentLoopData = $list_lang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($data->id); ?>" <?php if($data->id == $la->id): ?> style="display: none" <?php endif; ?>><?php echo e($data->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <button type="submit" class="btn btn-primary mb-2">Import Now</button>
                            </form>

                            <small style="color: red">If you import keywords from another language, Your present "<?php echo e($la->name); ?>" all keywords will remove.</small>

                        </div>
                    </div>
                </div>


                <form method="post" action="<?php echo e(route('admin.key-update', $la->id)); ?>" id="langForm">
                    <?php echo e(csrf_field()); ?>

                    <?php echo e(method_field('put')); ?>

                    <div class="card-body" style="overflow: hidden">

                        <div class="form-body">

                            <div class="row">
                                <div class="col-md-3 mt-2" v-for="(value, key) in datas" :key="key">
                                    <label class="control-label">{{ key }}</label>
                                    <div class="input-group">
                                        <input type="text" :value="value" :name="'keys[' + key + ']'" class="form-control form-control-lg">
                                        <div class="input-group-append" >
                                            <span class="input-group-text" style="background: #ff4f59; color: white" @click.prevent="deleteElement(key)"><i class="fa fa-trash"></i></span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <br>
                            <br>

                            <div class="row">
                                <div class="col-md-12 text-center">
                                    <button type="button" data-toggle="modal" data-target="#addModal" class="btn btn-primary">Add Translatable Key</button>
                                    <button class="btn btn-success" data-toggle="tooltip" title="<?php echo app('translator')->getFromJson('Save'); ?>" @click.prevent="save" style="display: none">Save</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer">
                        <button class="btn btn-primary btn-block btn-lg"><i class="fa fa-send"></i> Update</button>
                    </div>

                </form>
            </div>




            <div class="modal fade" id="addModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <form id="newlangForm">
                            <div class="modal-body">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">English</label>
                                    <input type="text" class="form-control" v-model="newKey" required>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputPassword1"><?php echo e($la->name); ?></label>
                                    <input type="text" class="form-control" v-model="newVal" required>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <input type="submit" class="btn btn-primary" value="Add Field" @click.prevent="addfield()">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>


        </div>
    </main>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('assets/admin/vue/vue.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/vue/axios.js')); ?>"></script>
  

    <script>
        window.app = new Vue({
            el: '#app',
            data: {
                datas: <?php echo $json;  ?> ,
                current: '<?php echo e($la->code); ?>',
                newVal: null,
                newKey: null,


                importData : {
                    code : ''
                }

            },
            methods: {
                save() {
                    $('#langForm').submit();
                },

                deleteElement(key) {
                    Vue.delete(this.datas, key);
                },
                addfield() {
                    Vue.set(this.datas, this.newKey, this.newVal);
                    app.newKey = '';
                    app.newVal = '';
                    // document.getElementById('newlangForm').reset();
                    $("#addModal").modal('hide');
                },
                importKey()
                {
                   __csrf_field() 
                    var code = this.importData;
                    axios.post('<?php echo e(route('admin.import_lang')); ?>', code).then(function (res) {
                        app.datas = res.data;
                    })

                }
            }
        })
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>