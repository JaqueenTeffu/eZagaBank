<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->getFromJson('Transfer'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('user.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/admin/css/toastr.min.css')); ?>">
    <section id="paymentMethod">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-10 col-lg-12 text-center">
                    <div class="heading-title padding-bottom-70">
                        <h2>
                            <?php echo app('translator')->getFromJson('Transfer to own bank'); ?>
                        </h2>
                        <div class="sectionSeparator"></div>

                    </div>
                </div>
            </div>

            <div class="row calculate justify-content-center">
                <div class="col-md-10 col-lg-12">
                    <div class="box">

                        <form method="post" action="<?php echo e(route('user.transfer.ownbank')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="col-md-12 text-center">
                                        <div role="alert" class="alert alert-danger margin-bottom-30">
                                            <strong><?php echo app('translator')->getFromJson('Balance Transfer Charge'); ?> <?php echo e($gnl->bal_trans_fixed_charge); ?> <?php echo e($gnl->cur); ?> <?php echo app('translator')->getFromJson('Fixed and'); ?>  <?php echo e($gnl->bal_trans_per_charge); ?> <?php echo app('translator')->getFromJson('% of your total amount to transfer balance.'); ?></strong>
                                        </div>
                                    </div>
                                    <div class="form-row">
                                        <div class="form-group col-md-8">
                                            <label><?php echo app('translator')->getFromJson('Account Number'); ?></label>
                                            <input type="text" name="account_number" class="myForn" placeholder="<?php echo app('translator')->getFromJson('account number'); ?>" autocomplete="off" required>
                                        </div>
                                       
                                        <div class="form-group col-md-4">
                                            <label><?php echo app('translator')->getFromJson('Amount'); ?></label>
                                            <input type="text"  name="amount" class="myForn" placeholder="<?php echo app('translator')->getFromJson('amount'); ?> <?php echo e($gnl->cur); ?>" autocomplete="off" required>
                                        </div>

                                        <div class="form-group padding-top-10 col-md-12">
                                            <button  class="btn" type="submit"><?php echo app('translator')->getFromJson('Transfer Balance'); ?></button>
                                        </div>

                                    </div>
                                </div>

                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <script type="text/javascript" src="<?php echo e(asset('assets/admin/js/toastr.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>