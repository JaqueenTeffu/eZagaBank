<!DOCTYPE html>
<!--[if lt IE 7 ]><html class="ie ie6" lang="en"> <![endif]-->
<!--[if IE 7 ]><html class="ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!-->
<html lang="zxx">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, maximum-scale=1, initial-scale=1, user-scalable=0">
    <meta name="keywords" content="">
    <meta name="description" content="">
    <title> <?php echo e($gnl->title); ?> | <?php echo $__env->yieldContent('title'); ?> </title>
    <!--Favicon-->
    <link rel="shortcut icon" href="<?php echo e(asset('assets/image/favicon.png')); ?>" type="image/x-icon">
    <!--Bootstrap Stylesheet-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/frontend/css/bootstrap.css')); ?>">
    <!--Font Awesome Stylesheet-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/frontend/css/all.min.css')); ?>">
    <!--Animate Stylesheet-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/frontend/css/animate.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/frontend/css/owl.carousel.css')); ?>">




    <!--Main Stylesheet-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/frontend/css/style.css')); ?>">

    <!--Responsive Stylesheet-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/frontend/css/responsive.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/admin/css/toastr.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="//maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <?php echo $__env->yieldContent('style'); ?>
    <link href="<?php echo e(url('/')); ?>/assets/frontend/css/color.php?color=<?php echo e($gnl->color1); ?>" rel="stylesheet">

</head>

<body class="body-class">
<!--Start Preloader-->
<div class="site-preloader">
    <div class="spinner">
        <div class="double-bounce1"></div>
        <div class="double-bounce2"></div>
    </div>
</div>
<!--End Preloader-->

<!-- Main Menu Area Start -->
<header id="mainHeader" class="header">
    <!-- Start Navigation -->
    <nav class="navbar navbar-expand-lg navbar-light p-0">
        <div class="container">
            <a class="navbar-brand" href="<?php echo e(route('homePage')); ?>">
                <img src="<?php echo e(asset('assets/image/logo.png')); ?>" style="max-width: 220px; max-height: 50px;">
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                    aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('homePage')); ?>"><?php echo app('translator')->getFromJson('Home'); ?></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php if(request()->route()->getName() == 'homePage'): ?>#aboutUs <?php else: ?><?php echo e(route('homePage')); ?>#aboutUs <?php endif; ?>"><?php echo app('translator')->getFromJson('About'); ?></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php if(request()->route()->getName() == 'homePage'): ?>#services <?php else: ?><?php echo e(route('homePage')); ?>#services <?php endif; ?>"><?php echo app('translator')->getFromJson('Services'); ?></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('blog')); ?>"><?php echo app('translator')->getFromJson('Latest News'); ?></a>
                    </li>


                    <li class="nav-item">
                        <a class="nav-link" href="<?php if(request()->route()->getName() == 'homePage'): ?>#faq <?php else: ?><?php echo e(route('homePage')); ?>#faq <?php endif; ?>"><?php echo app('translator')->getFromJson('Faq'); ?></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('contact')); ?>"><?php echo app('translator')->getFromJson('Contact'); ?></a>
                    </li>
                    <select id="langSel">
                        <option style="color: black" value="en"> English</option>
                        <?php $__currentLoopData = $lang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e(strtolower($data->code)); ?>" <?php if(Session::get('lang') == strtolower($data->code)): ?> selected="selected" <?php endif; ?> style="color: black"><img src="<?php echo e(asset('assets/image/lang/'.$data->icon)); ?>"> <?php echo e($data->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                </ul>
                <div class="viewPlan">
                    <a href="<?php echo e(route('login')); ?>">
                        <?php echo app('translator')->getFromJson('Sign in'); ?>
                    </a>
                </div>
                <div class="viewPlan">
                    <a href="<?php echo e(route('register')); ?>">
                        <?php echo app('translator')->getFromJson('Sign up'); ?>
                    </a>
                </div>
            </div>
        </div>
    </nav>
    <!-- End Navigation -->
    <div class="clearfix"></div>
</header>
<!-- Main Menu Area End -->

<?php echo $__env->yieldContent('content'); ?>

<!-- Footer Area Start -->
<footer id="footer">
    <div class="container">
        <div class="row newslatterBox">
            <div class="col-12">
                <div class="box d-flex">
                    <div class="left">
                        <h2>
                            <?php echo app('translator')->getFromJson('Join Our Newsletter'); ?>
                        </h2>
                        <div class="sectionSeparator"></div>
                    </div>
                    <div class="right">
                        <form action="<?php echo e(route('subscribePost')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <input type="text" name="email" placeholder="<?php echo app('translator')->getFromJson('Enter your email'); ?>">
                            <button type="submit"><?php echo app('translator')->getFromJson('Subscribe'); ?></button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-5">
                <div class="box">
                    <div class="logo">
                        <a href="<?php echo e(route('homePage')); ?>">
                            <?php echo e($gnl->title); ?>

                        </a>
                    </div>
                    <p>
                         <?php echo e(__($gnl->about_subtitle)); ?>

                    </p>
                    <div class="social_links">
                        <ul>


                            <?php $__currentLoopData = $socials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <a href="<?php echo e($social->link); ?>">
                                        <i title="<?php echo e($social->name); ?>" class="<?php echo e($social->icon); ?>"></i>
                                    </a>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="col-lg-4">

            </div>
            <div class="col-lg-3">
                <div class="box box4">
                    <h2 >
                       <?php echo app('translator')->getFromJson(' Contact Us'); ?>
                    </h2>
                    <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p style="padding-top: 10px">
                            <?php echo e($contact->name); ?>

                        </p>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>

    </div>
    <div class="copyright">
        <p class="text-center">
            <?php echo e($gnl->branding); ?>

        </p>
    </div>
</footer>


<!--Start ClickToTop-->
<div class="totop">
    <a href="#top"><i class="fa fa-arrow-up"></i></a>
</div>
<!--End ClickToTop-->


<!--jQuery JS-->
<script src="<?php echo e(asset('assets/frontend/js/jquery.min.js')); ?>"></script>
<!--Bootstrap JS-->
<script src="<?php echo e(asset('assets/frontend/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/frontend/js/popper.js')); ?>"></script>
<script src="<?php echo e(asset('assets/frontend/js/owl.carousel.min.js')); ?>"></script>

<!--YTPlayer-->

<script>
    $(document).on('change', '#langSel', function () {
        var code = $(this).val();
        window.location.href = "<?php echo e(url('/')); ?>/change-lang/"+code ;
    });
</script>
<!-- main js -->
<script src="<?php echo e(asset('assets/frontend/js/main.js')); ?>"></script>
<?php echo $__env->yieldContent('script'); ?>
<script type="text/javascript" src="<?php echo e(asset('assets/frontend/js/toastr.min.js')); ?>"></script>
<?php echo $__env->make('notification.notification', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>