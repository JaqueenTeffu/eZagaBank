<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * @method static findOrFail($id)
 */
class Partner extends Model
{
    protected $guarded = ['id'];




}
